package Kimhyojun.domain;

public class Student {
    public int num;
    public String name;
    public String sex;
    public int[] score;

    public Student(int num, String name, String sex, int[] score) {
        this.num = num;
        this.name = name;
        this.sex = sex;
        this.score = score;
    }
}
